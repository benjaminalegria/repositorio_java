package com.mycompany.evaluacionparcial1;

{
 id: String
 nombre: String
 precio: double
 Producto(id:String, nombre:String, precio:double)
 getId():String
 getNombre():String
 getPrecio():double
 setPrecio(precio:double):void
 toString():String
}



public class Producto {
  private String id;
    private String nombre;
    private double precio;

    public Producto(String id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        setPrecio(precio);
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio > 0) {
            this.precio = precio;
        } else {
            throw new IllegalArgumentException("El precio debe ser mayor a 0");
        }
    }

    @Override
    public String toString() {
        return "Producto{" + "id='" + id + '\'' + ", nombre='" + nombre + '\'' + ", precio=" + precio + '}';
    }
}   

