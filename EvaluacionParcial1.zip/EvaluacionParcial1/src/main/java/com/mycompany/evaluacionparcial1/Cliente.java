

package com.mycompany.evaluacionparcial1;{
 idCliente: String
 nombre: String
 categoria: String
 carrito: CarritoDeCompras
 Cliente(idCliente:String, nombre:String, categoria:String)
 getCarrito():CarritoDeCompras
 aplicarDescuentoSiCorresponde():void
 toString():String
}



public class Cliente {
private String idCliente;
    private String nombre;
    private String categoria; // "GENERAL" o "ESTUDIANTE"
    private CarritoDeCompras carrito;

    public Cliente(String idCliente, String nombre, String categoria) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.categoria = categoria;
        this.carrito = new CarritoDeCompras();
    }

    public CarritoDeCompras getCarrito() {
        return carrito;
    }

    public void aplicarDescuentoSiCorresponde() {
        if (categoria.equalsIgnoreCase("ESTUDIANTE")) {
            double descuento = carrito.getTotal() * 0.10;
            System.out.println("Descuento aplicado: " + descuento);
        }
    }

    @Override
    public String toString() {
        return "Cliente{" + "id='" + idCliente + '\'' + ", nombre='" + nombre + '\'' + ", categoria='" + categoria + '\'' + '}';
    }    
}
