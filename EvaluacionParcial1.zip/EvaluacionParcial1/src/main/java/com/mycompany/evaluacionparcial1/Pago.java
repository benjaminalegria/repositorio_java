package com.mycompany.evaluacionparcial1;

{
 monto: double
 medio: String
 autorizado: boolean
 Pago(monto:double, medio:String)
 autorizar():boolean
 emitirComprobante():String
}



public class Pago {
  private double monto;
    private String medio;
    private boolean autorizado;

    public Pago(double monto, String medio) {
        this.monto = monto;
        this.medio = medio;
        this.autorizado = false;
    }

    public boolean autorizar() {
        if (monto <= 200000 && (medio.equalsIgnoreCase("DEBITO") || medio.equalsIgnoreCase("CREDITO"))) {
            autorizado = true;
        } else {
            autorizado = false;
        }
        return autorizado;
    }

    public String emitirComprobante() {
        return (autorizado ? "APROBADO" : "RECHAZADO") +
                " – Monto: " + monto + " – Medio: " + medio;
    }  
}
