package com.mycompany.evaluacionparcial1;

{
main(String[] args):void
}




public class EvaluacionParcial1 {

    public static void main(String[] args) {
       
    Producto p1 = new Producto("P001", "Laptop", 150000);
        Producto p2 = new Producto("P002", "Mouse", 10000);
        Producto p3 = new Producto("P003", "Teclado", 20000);

        
        Cliente cliente = new Cliente("C001", "Benjamín", "ESTUDIANTE");

        
        cliente.getCarrito().agregarProducto(p1);
        cliente.getCarrito().agregarProducto(p2);

        
        cliente.getCarrito().eliminarProductoPorId("P002");

        
        cliente.aplicarDescuentoSiCorresponde();

        
        double total = cliente.getCarrito().getTotal() * (cliente.toString().contains("ESTUDIANTE") ? 0.9 : 1);
        Pago pago = new Pago(total, "DEBITO");
        pago.autorizar();

        
        System.out.println(cliente);
        System.out.println(cliente.getCarrito());
        System.out.println(pago.emitirComprobante());
    }    
    }


}
