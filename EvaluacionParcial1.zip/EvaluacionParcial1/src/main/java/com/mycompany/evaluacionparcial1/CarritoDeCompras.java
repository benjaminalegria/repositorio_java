package com.mycompany.evaluacionparcial1;
import java.util.ArrayList;
productos: ArrayList<Producto>
 total: double
 CarritoDeCompras()
 agregarProducto(p:Producto):void
 eliminarProductoPorId(id:String):boolean
 getTotal():double
+ toString():String

public class CarritoDeCompras {

 private final ArrayList<Producto> productos;
    private double total;

    public CarritoDeCompras() {
        productos = new ArrayList<>();
        total = 0;
    }

    public void agregarProducto(Producto p) {
        productos.add(p);
        total += p.getPrecio();
    }

    public boolean eliminarProductoPorId(String id) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                total -= p.getPrecio();
                productos.remove(p);
                return true;
            }
        }
        return false;
    }

    public double getTotal() {
        return total;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Carrito:\n");
        for (Producto p : productos) {
            sb.append(p.toString()).append("\n");
        }
        sb.append("Total: ").append(total);
        return sb.toString();
    }
}   
    

    


